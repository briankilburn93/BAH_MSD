package com.bah.msd.auth.jwt;

import com.bah.msd.auth.pojos.Token;

public interface JWTUtil {
	public boolean verifyToken(String jwt_token);
	public String getScopes(String jwt_token) ;
	public Token createToken(String scopes) ;
}