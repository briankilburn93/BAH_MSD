package com.bah.msd.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MccProjectAuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(MccProjectAuthApplication.class, args);
	}

}
